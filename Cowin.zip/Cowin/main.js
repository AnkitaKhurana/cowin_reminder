const axios = require("axios");
const https = require("https");
// var currentDate = new Date();
// currentDate.setDate(currentDate.getDate() + 1);
// console.log(currentDate.toLocaleDateString("en-GB").split("/").join("-"));
const today = new Date().toLocaleDateString("en-GB").split("/").join("-");
var cron = require("node-cron");
var player = require("play-sound")((opts = {}));
let districts = [650,140,144,149,145]//, 140,143,145, 148,188,199];
let audio = null;
const Say = require('say').Say
const say = new Say('darwin' || 'win32' || 'linux')

// public : https://cdn-api.co-vin.in/api/v2/appointment/sessions/public/calendarByDistrict?district_id=
// private : https://cdn-api.co-vin.in/api/v2/appointment/sessions/calendarByDistrict?district_id=
function checkSlot() {
  for (let id of districts) {
    say.stop();
     axios
      .get(
        'https://cdn-api.co-vin.in/api/v2/appointment/sessions/calendarByDistrict?district_id=' +
          id +
          "&date=" +
          today,
        {
          headers: {
            "User-Agent":
              "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36",
          },
        }
      )
      .then((data) => data.data)
      .then((result) => {
        let availableCenters = [];
        let centers = result.centers;
        let covaxinCenters = centers.filter((center) => {
          let stringcenter = JSON.stringify(center);
          if (stringcenter.toLowerCase().search("covaxin") != -1) {
            return true;
          }
          return false;
        });
        covaxinCenters.forEach((center) => {
          let sessions = center.sessions;
          sessions.forEach((session) => {
            // ||center.district_name=='Gautam Buddha Nagar' )
             if (session.available_capacity > 0 && session.min_age_limit == 18 && session.date!="15-05-2021"&& session.date!="17-05-2021"&& session.date!="16-05-2021"&& session.date!="19-05-2021" && session.date!="26-05-2021") {
              availableCenters.push(center);
              console.log(session.available_capacity)
              console.log(JSON.parse(JSON.stringify(session)));
              console.log("*************************");
             console.log("*************************"); 
              console.log("*************************");

            }
          });
        });
        if (audio) {
          audio.kill();
        }
        if (availableCenters.length > 0) {
          console.log("*************************");
          console.log("*************************");
          console.log(centers[0].state_name);
          console.log(availableCenters);
          console.log("*************************");    
          let audioFile = "";
          console.log(id);
          if (id == 650) {
            audioFile = "noida.mp3";
            say.speak("Noida Noida Noida");
 

          } 
          else if(id == 149 ){
            audioFile = "southdelhi.mp3";
            say.speak(" South Delhi South Delhi South Delhi South Delhi");

          }
          else if(id == 140 ){
            audioFile = "newdelhi.mp3";
            say.speak("New Delhi New Delhi New Delhi New Delhi");

          }
          else if(id == 143 ){
            audioFile = "newdelhi.mp3";
            say.speak("North West delhi North West delhi North West delhi");
 

          }
          else if(id == 144 ){
            audioFile = "southeastdelhi.mp3";
          // say.speak("South East Delhi South East Delhi South East Delhi");
 

          }
          else if(id == 145 ){
            say.speak("East delhi east delhi east delhi");
 

          }
          else if(id == 148 ){
            say.speak("Shadra Shadra Shadra");
 

          }
          else if(id == 188 ){
            say.speak("Gurgaon Gurgaon Gurgaon");
 

          }
          else if(id == 199 ){
            say.speak("Faridabad Faridabad Faridabad");
 

          }
          else audioFile = "alert.mp3";

          audio = player.play('alert.mp3', function (err) {
            if (err) throw err;
          });

         // return availableCenters;
        } else {
          if (audio) audio.kill();
        }
      })
      .catch((err) => console.log("error->" + JSON.stringify(err)));
  }
}

cron.schedule("*/4 * * * * *", () => {
  console.log("running a task every sec");
  checkSlot();
});
// https.createServer(function (req, res) {
//   res.writeHead(200, {'Content-Type': 'text/plain'});
// ///  res.writeHead(200);
//   //console.log(checkSlot())
//   res.end('ok');
// }).listen(8082);
